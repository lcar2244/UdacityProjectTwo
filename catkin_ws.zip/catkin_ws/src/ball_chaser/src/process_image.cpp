 #include "ros/ros.h"
#include "ball_chaser/DriveToTarget.h"
#include <sensor_msgs/Image.h>


// Define a global client that can request services
ros::ServiceClient client;

// This function calls the command_robot service to drive the robot in the specified direction
void drive_robot(float lin_x, float ang_z)
{
    // TODO: Request a service and pass the velocities to it to drive the robot
  ROS_INFO_STREAM("Driving the robot to the target.");
  
  //send requests
  ball_chaser::DriveToTarget srv;
  srv.request.linear_x = lin_x;
  srv.request.angular_z = ang_z;
  
  //failed call
   if (!client.call(srv))
        ROS_ERROR("Failed to call service safe_move");
  
 
}

// This callback function continuously executes and reads the image data
void process_image_callback(const sensor_msgs::Image img)
{

    int white_pixel = 255;

    // TODO: Loop through each pixel in the image and check if there's a bright white one
  /*
  // taken from sensor_msgs/image ROS Documentation
  # This message contains an uncompressed image
# (0, 0) is at top-left corner of image
#

Header header        # Header timestamp should be acquisition time of image
                     # Header frame_id should be optical frame of camera
                     # origin of frame should be optical center of camera
                     # +x should point to the right in the image
                     # +y should point down in the image
                     # +z should point into to plane of the image
                     # If the frame_id here and the frame_id of the CameraInfo
                     # message associated with the image conflict
                     # the behavior is undefined

uint32 height         # image height, that is, number of rows
uint32 width          # image width, that is, number of columns

# The legal values for encoding are in file src/image_encodings.cpp
# If you want to standardize a new string format, join
# ros-users@lists.sourceforge.net and send an email proposing a new encoding.

string encoding       # Encoding of pixels -- channel meaning, ordering, size
                      # taken from the list of strings in include/sensor_msgs/image_encodings.h

uint8 is_bigendian    # is this data bigendian?
uint32 step           # Full row length in bytes
uint8[] data          # actual matrix data, size is (step * rows)
  */
    
  
  
  //set variables  
  
  int count = 0;
  float sum_step = 0.0;
  
 
  
  //loop finding ball and position
  for (int i = 0; i < img.height ; i++){
    
      for (int j = 0; j < img.step; j++){
        
        if (img.data[i*j] == white_pixel) {
          sum_step += j;
          count++;
          
     	 }
      }
  }
  
    // Then, identify if this pixel falls in the left, mid, or right side of the image
  float center = sum_step/count;
  float direction = center/img.step;
  float x = 0.0;
  float z = 0.0;

  //no pixel, stop
  if (count == 0){
    x= 0.0;
    z= 0.0;
  }
 
  //move to ball
	if (direction > 0.66){
      x = 0.1;
      z = .10;
      ROS_INFO_STREAM("Right");
      
    }
      if (direction <= 0.66 && direction >= 0.33){
      x = 0.1;
      z = 0.0;
        ROS_INFO_STREAM("Middle");
    }
  if (direction < 0.33){
      x = 0.1;
      z = -.10;
    ROS_INFO_STREAM("Left");
    }
// Depending on the white ball position, call the drive_bot function and pass velocities to it
  // call bot
  drive_robot(x, z);
    // Request a stop when there's no white ball seen by the camera
}

int main(int argc, char** argv){


    // Initialize the process_image node and create a handle to it
    ros::init(argc, argv, "process_image");
    ros::NodeHandle n;

    // Define a client service capable of requesting services from command_robot
    client = n.serviceClient<ball_chaser::DriveToTarget>("/ball_chaser/command_robot");

    // Subscribe to /camera/rgb/image_raw topic to read the image data inside the process_image_callback function
    ros::Subscriber sub1 = n.subscribe("/camera/rgb/image_raw", 10, process_image_callback);

    // Handle ROS communication events
    ros::spin();

    return 0;

}